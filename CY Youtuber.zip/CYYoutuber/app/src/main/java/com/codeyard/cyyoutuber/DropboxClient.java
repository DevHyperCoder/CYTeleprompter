package com.codeyard.cyyoutuber;

import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.v2.DbxClientV2;

/**
 * Dropbox client get class
 * todo do the javadoc
 */
class DropboxClient {

    static DbxClientV2 getClient(String ACCESS_TOKEN) {
        // Create Dropbox client
        DbxRequestConfig config = new DbxRequestConfig("Teleprompter Client", "en_US");
        return new DbxClientV2(config, ACCESS_TOKEN);
    }
}
