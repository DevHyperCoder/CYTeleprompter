package com.codeyard.cyyoutuber;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    final static String TAG = "CYYoutuber";
    final static String TEXT = "TEXT";
    final static String TITLE = "TITLE";
    static final private List<String> titleList = new ArrayList<>();
    static final private List<String> linkList = new ArrayList<>();
    private static MainActivity mainActivity;
    private static ArrayAdapter<String> itemsAdapter;

    private static void vergeParse() {
        try {
            Document document = Jsoup.connect("https://theverge.com").get();
            Elements elements = document.select("h2.c-entry-box--compact__title");
            for (Element element : elements) {
                titleList.add(element.text());
            }
            elements = document.select("a.c-entry-box--compact__image-wrapper");
            for (Element element : elements) {
                linkList.add(element.attr("href"));
            }

        } catch (IOException ioE) {
            ioE.printStackTrace();
        }
    }

    private static void gadgetsNDTVParse() {
        try {
            Document document = Jsoup.connect("https://gadgets.ndtv.com/news").get();
            Elements elements = document.select("div.caption_box");
            for (Element element : elements) {
                titleList.add(element.text());

            }
            elements = document.select("div.thumb");
            Elements elements1 = elements.select("a");
            for (Element element : elements1) {
                linkList.add(element.attr("href"));
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
            Log.e(TAG, "gadgetsNDTVParse: IOException", ioException);
        }
    }

    private static void bgrParse() {
        try {
            Document doc = Jsoup.connect("https://www.bgr.in/category/news/").get();

            Elements elements = doc.select("a.mob_text_ln_aLink");
            for (Element element : elements) {
                if (!element.text().equals("")) {
                    titleList.add(element.text());
                    linkList.add(element.attr("href"));
                }

            }
            elements = doc.select("a.techNews_aLink");
            for (Element element : elements) {

                titleList.add(element.attr("title"));
                linkList.add(element.attr("href"));
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e(TAG, "bgrParse: IOException", e);
        }
    }

    private static void parseSite(String link) {
        final StringBuilder parsedData = new StringBuilder();
        try {
            Document document = Jsoup.connect(link).get();

            if (link.contains("theverge.com")) {
                Log.d(TAG, "parseSite: parsing the verge");
                Elements elements = document.select("p");
                for (Element element : elements) {
                    parsedData.append(element.text());

                }
            } else if (link.contains("gadgets.ndtv.com")) {
                Elements elements = document.select("div.content_text.row.description");
                for (Element element : elements) {
                    parsedData.append(element.text());
                }
            } else if (link.contains("bgr")) {
                Elements elements = document.select("div.article-content");
                for (Element element : elements) {
                    parsedData.append(element.text());

                }
            } else {
                Log.d(TAG, "parseSite: no site found");
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(mainActivity, "Couldn't parse the side", Toast.LENGTH_SHORT).show();
        }
        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                EditorActivity.updateEditText(parsedData.toString());
            }
        });

    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Setting the static context
        mainActivity = MainActivity.this;
        //Call the parse async task
        new ParseAsyncTask().execute();

        //display them
        ListView listView = findViewById(R.id.list_view);
        itemsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titleList);
        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d(TAG, "onItemClick: title : " + titleList.get(i));
                Log.d(TAG, "onItemClick: link : " + linkList.get(i));
                //parse the site and get the news..
                new ParseSiteAsyncTask().execute(linkList.get(i));
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                intent.putExtra(TEXT, "");
                intent.putExtra(TITLE, titleList.get(i));
                startActivity(intent);

            }
        });
    }

    private static class ParseSiteAsyncTask extends AsyncTask<String, String, String> {
        ProgressDialog progressBar;

        @Override
        public String doInBackground(String[] s) {
            parseSite(s[0]);
            progressBar.dismiss();
            return null;
        }

        @Override
        public void onPreExecute() {
            progressBar = ProgressDialog.show(mainActivity,
                    "Please wait",
                    "",
                    true,
                    false);

        }
    }

    private static class ParseAsyncTask extends AsyncTask<String, String, String> {

        ProgressDialog progressDialog;


        @Override
        protected String doInBackground(String[] objects) {
            //Parse all sites
            bgrParse();
            gadgetsNDTVParse();
            vergeParse();
            progressDialog.dismiss();
            //Notify the adapter that the data has been changed
            mainActivity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    itemsAdapter.notifyDataSetChanged();
                }
            });

            return null;
        }

        @Override
        protected void onPreExecute() {

            progressDialog = ProgressDialog.show(mainActivity,
                    "Please wait",
                    "",
                    true,
                    false);
        }


    }
}


