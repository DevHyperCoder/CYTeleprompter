package com.codeyard.cyyoutuber;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;


public class EditorActivity extends AppCompatActivity {
    final static String ACCESS_TOKEN_KEY = "ACCESS_TOKEN_KEY";
    @SuppressLint("StaticFieldLeak")
    static EditorActivity editorActivity;
    @SuppressLint("StaticFieldLeak")
    static private EditText editText;
    private String ACCESS_TOKEN = "";

    static void updateEditText(String newData) {
        if (editorActivity != null) {
            Toast.makeText(editorActivity, "New data came through", Toast.LENGTH_SHORT).show();
        }
        editText.setText(newData);
        setClipboard(editorActivity, newData);

    }

    static private void setClipboard(Context context, String text) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(editorActivity, "Copied to clipboard", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        Intent intent = getIntent();
        ///final String text = intent.getStringExtra(MainActivity.TEXT);
        final String title = intent.getStringExtra(MainActivity.TITLE);
        if (!tokenExists()) {//No token
            //Back to LoginActivity
            Intent intent1 = new Intent(EditorActivity.this, LoginActivity.class);
            startActivity(intent1);
        }
        editorActivity = EditorActivity.this;
        ACCESS_TOKEN = retrieveAccessToken();
        getUserAccount();
        Button saveButton = findViewById(R.id.save);
        editText = findViewById(R.id.edit_text);
        //editText.setText(text);
        //setClipboard(EditorActivity.this, text);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String editedText = editText.getText().toString();
                Log.d(MainActivity.TAG, "onClick: edited text is : " + editedText);
                upload(title, editedText);
            }
        });
    }

    private void getUserAccount() {
        if (ACCESS_TOKEN == null) return;
        new UserAccountTask(DropboxClient.getClient(ACCESS_TOKEN), new UserAccountTask.TaskDelegate() {
            @Override
            public void onAccountReceived() {
                Log.d("User data", "received account details.");
            }

            @Override
            public void onError(Exception error) {
                Log.d("User data", "Error receiving account details.", error);
            }
        }).execute();
    }

    private void upload(String title, String text) {
        Log.d(MainActivity.TAG, "upload: " + title);
        new UploadTask(DropboxClient.getClient(ACCESS_TOKEN), title, text, EditorActivity.this).execute();
    }

    private boolean tokenExists() {
        SharedPreferences prefs = getSharedPreferences(ACCESS_TOKEN_KEY, Context.MODE_PRIVATE);
        String accessToken = prefs.getString("access-token", null);
        return accessToken != null;
    }

    private String readClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        String pasteData;
        ClipData.Item item = Objects.requireNonNull(clipboard.getPrimaryClip()).getItemAt(0);
        // Gets the clipboard as text.
        pasteData = (String) item.getText();
        Toast.makeText(this, "Pasted from clipboard", Toast.LENGTH_SHORT).show();
        return pasteData;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.Paste) {
            String data = readClipboard();
            editText.setText(data);
            return true;
        }
        return false;
    }

    private String retrieveAccessToken() {
        //check if ACCESS_TOKEN is previously stored on previous app launches
        SharedPreferences prefs = getSharedPreferences(ACCESS_TOKEN_KEY, Context.MODE_PRIVATE);
        String accessToken = prefs.getString("access-token", null);
        if (accessToken == null) {
            Log.d("AccessToken Status", "No token found");
            return null;
        } else {
            //accessToken already exists
            Log.d("AccessToken Status", "Token exists");
            return accessToken;
        }
    }
}